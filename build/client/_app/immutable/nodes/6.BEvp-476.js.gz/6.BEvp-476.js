import"../chunks/DBavZ5B7.js";import"../chunks/DS0lvVqG.js";function _page(e){}(0,Object.defineProperty)(_page,"name",{value:"_page",configurable:!0});export{_page as component};
//# sourceMappingURL=6.BEvp-476.js.map
