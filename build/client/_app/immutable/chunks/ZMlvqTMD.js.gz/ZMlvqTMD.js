import{h as o,x as s}from"./Ces5mITZ.js";function slot(l,t,e,r,a){var i;o&&s();var n=null==(i=t.$$slots)?void 0:i[e],v=!1;!0===n&&(n=t.children,v=!0),void 0===n||n(l,v?()=>r:r)}(0,Object.defineProperty)(slot,"name",{value:"slot",configurable:!0});export{slot as s};
//# sourceMappingURL=ZMlvqTMD.js.map
