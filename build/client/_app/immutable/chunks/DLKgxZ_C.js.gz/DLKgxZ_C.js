var e=Object.defineProperty;let a=!1,l=!1;function enable_legacy_mode_flag(){a=!0}e(enable_legacy_mode_flag,"name",{value:"enable_legacy_mode_flag",configurable:!0});export{enable_legacy_mode_flag as e,a as l,l as t};
//# sourceMappingURL=DLKgxZ_C.js.map
