import{l as s,a as r}from"../chunks/DLdyWM6x.js";export{s as load_css,r as start};
//# sourceMappingURL=start.CPh-_CZU.js.map
