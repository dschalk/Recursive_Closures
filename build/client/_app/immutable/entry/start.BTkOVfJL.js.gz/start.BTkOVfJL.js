import{l as s,a as r}from"../chunks/C2Uuf7vX.js";export{s as load_css,r as start};
//# sourceMappingURL=start.BTkOVfJL.js.map
