import{l as s,a as o}from"../chunks/Db5OfBRJ.js";export{s as load_css,o as start};
//# sourceMappingURL=start.B0YFx-bI.js.map
