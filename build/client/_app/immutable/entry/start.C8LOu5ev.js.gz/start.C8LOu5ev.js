import{l as s,a as o}from"../chunks/zboitJZR.js";export{s as load_css,o as start};
//# sourceMappingURL=start.C8LOu5ev.js.map
