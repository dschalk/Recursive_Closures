import{l as s,a as r}from"../chunks/CTBee6e-.js";export{s as load_css,r as start};
//# sourceMappingURL=start.qF6BAHtr.js.map
