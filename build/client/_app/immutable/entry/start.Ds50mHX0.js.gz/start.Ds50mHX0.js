import{l as s,a as o}from"../chunks/CgTDWkQb.js";export{s as load_css,o as start};
//# sourceMappingURL=start.Ds50mHX0.js.map
