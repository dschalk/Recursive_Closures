import{l as s,a as r}from"../chunks/DFdhCFKu.js";export{s as load_css,r as start};
//# sourceMappingURL=start.I4xpsNrE.js.map
